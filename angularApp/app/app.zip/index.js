// app.js
const express = require('express');  
const app = express();  
const server = require('http').createServer(app);  
const io = require('socket.io')(server);


const port = 9000;

var citiesStatus

app.use(express.static(__dirname ));


app.get('/', function (req, res) {
  res.sendFile( './index.html');
});

io.on("connection", client => {  
  console.log('Client connected...');

  client.on("citiesStatus", citiesStatus => {
    console.log(citiesStatus);
  });


});

server.listen(port, '0.0.0.0');
console.log("App listening on port " + port);


var request = require('request');

request.get(
    'https://query.yahooapis.com/v1/public/yql?q=select * from weather.forecast where woeid =468739&format=json',
    { json: { key: 'value' } },
    function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(JSON.stringify(body));
        }
    }
);




var i = 0;
const to = setInterval(() => {
	if(i>10){
		clearInterval(to);
	}
	i++;
	console.log(i);
	
}, 10000);