'use strict';

/**
 * @ngdoc function
 * @name weatherBoardApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * Controller of the weatherBoardApp
 */
weatherBoardApp
    .controller('LoginCtrl', ($rootScope, $scope, ngNotify, loginService, mainService, boardsService, dataService) => {


    })
