'use strict';

/**
 * @ngdoc overview
 * @name weatherBoardApp
 * @description
 * # weatherBoardApp
 *
 * Main module of the application.
 */
const weatherBoardApp = angular.module("weatherBoardApp", ["ngNotify", "ngCookies"])