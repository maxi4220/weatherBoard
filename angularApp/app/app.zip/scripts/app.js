'use strict';

/**
 * @ngdoc overview
 * @name weatherBoardApp
 * @description
 * # weatherBoardApp
 *
 * Main module of the application.
 */
var weatherBoardApp = angular.module("weatherBoardApp", ["ngNotify"])